const { sendResponse } = require('../utils/response');
const db = require('../db');
const ExcelJS = require('exceljs');
const path = require('path');
const fs = require('fs'); // Import the fs module

exports.getCategories = (req, res) => {
  try {
   
  } catch (error) {
    console.error('Unexpected error:', error.message);
    sendResponse(res, false, 'Failed to fetch categories', null);
  }
};
