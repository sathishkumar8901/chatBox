const { sendResponse } = require('../utils/response');
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const db = require('../db')
const secretKey = 'Password@#857';
const excel = require("exceljs");
const path = require('path');
exports.regiserUser = (async (req,res) => {
   
    const {name,password} = req.body;
    
    const hashedPassword = await bcrypt.hash(password,10);
    if(name.length == 0)
    {
        return res.status(400).json({message : "Please Enter the Name"})
    }
    if(password.length == 0)
    {
        return res.status(400).json({message : "Please Enter the Password"})
    }
   
    db.query("select * from user where name = ?",[name],async(err,result) => {
        if(err)  return res.status(500).json({message : 'Data not found'})

            db.query("insert into user (name,password) VALUES (?,?)",[name,hashedPassword],(err) => {
                if(err)  return res.status(500).json({message : 'Error While Register Scenario'})
                res.status(201).json({messge : 'User Register Successfully'})
            })
    })
   
})

exports.login = ((req,res) => {
    const {name,password} = req.body;
    if(name.length == 0)
    {
        return res.status(400).json({message : "Please Enter the Name"})
    }
    if(password.length == 0)
    {
        return res.status(400).json({message : "Please Enter the Password"})
    }
    db.query("select * from user where name = ?",[name],async(err,result) => {
        if(err)  return res.status(500).json({message : 'Data not found'})
        if(result.length == 0) return res.status(201).json({message : "Invalid Username or Password"})
        const user = result[0];
        const ispasswordValid = await bcrypt.compare(password,user.password)
        if(!ispasswordValid)
        {
            return res.status(201).json({message : "Invalid Username or Password"})
        }

        const token = jwt.sign({id:user.id,username : user.name},secretKey,{expiresIn: '1h'})
        res.status(200).json({messge : 'Login Successfully',token})

    })
})

exports.exportCSV = ((req,res,next) => {
    const authToken = req.headers.authorization;
    if(!authToken) res.status(201).json({message : "No token founded"})

    const token = authToken.split(' ')[1]; // Bearer <token>

    jwt.verify(token, secretKey, (err, payload) => {
      if (err) {
        return res.status(403).json({
          success: false,
          message: 'Invalid token',
        });
      } else {
        req.user = payload;
        next();
      }
    });
    db.query("select * from chatbox",async(err,results) => {
        
        if(err) return res.status(500).json({message : 'Data not found'})
        let workbook = new excel.Workbook();
        let worksheet = workbook.addWorksheet("chatBox");

        worksheet.columns = [
            { header: "Id", key: "id", width: 5 },
            { header: "From User", key: "user_id", width: 15 },
            { header: "To User", key: "to_id", width: 15 },
            { header: "Message", key: "message", width: 30 },
            {header : "Message Time",key:"created_at",width:55}
          ];

          worksheet.addRows(results);
   

          workbook.xlsx.writeFile("chat.xlsx").then(() => {
            });
          res.status(200).json({messge : 'Chat Exported Successfully'})
          
    })
})