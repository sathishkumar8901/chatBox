const express = require('express');
const router = express.Router();
const categoryController = require('../controller/categoryController');
const userController = require('../controller/userController')

router.get('/', categoryController.getCategories); 
router.post('/registerUser',userController.regiserUser)
router.post('/login',userController.login)
router.get('/csvExport',userController.exportCSV)


module.exports = router;
