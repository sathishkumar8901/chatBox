-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2024 at 01:25 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rds`
--

-- --------------------------------------------------------

--
-- Table structure for table `giftcard_category_pos`
--

CREATE TABLE `giftcard_category_pos` (
  `Id` int(11) NOT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `category_image` text DEFAULT NULL,
  `country_id` int(11) NOT NULL,
  `category_tc` varchar(100) DEFAULT NULL,
  `category_type` tinyint(1) DEFAULT 0 COMMENT '0 - E_Giftcard, 1 - Physical',
  `sortorder` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `isDelete` varchar(100) DEFAULT NULL,
  `Created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `Updated_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `giftcard_category_pos`
--

INSERT INTO `giftcard_category_pos` (`Id`, `category_name`, `category_image`, `country_id`, `category_tc`, `category_type`, `sortorder`, `page_id`, `status`, `isDelete`, `Created_date`, `Updated_date`) VALUES
(3, 'E-Gift Card', 'assets/images/gift-card.png', 1, NULL, 0, 1, 1, 1, NULL, '2024-11-21 15:34:34', '2024-11-21 16:48:33'),
(4, 'E-Gift Card', 'assets/images/gift-card-1.png', 1, NULL, 1, 1, 1, 1, NULL, '2024-11-21 15:35:27', '2024-11-21 16:48:30'),
(5, 'Gold Lounge Experience', 'assets/images/gift-card-2.png', 1, NULL, 1, 2, 1, 1, NULL, '2024-11-21 15:36:05', '2024-11-21 16:48:25'),
(6, 'Gold Lounge Experience - 1', 'assets/images/gift-card-3.png', 1, NULL, 1, 3, 1, 1, NULL, '2024-11-21 15:36:36', '2024-11-21 16:48:44'),
(7, 'E-Gift Card - 1', 'assets/images/gift-card-4.png', 1, NULL, 1, 4, 1, 1, NULL, '2024-11-21 15:37:16', '2024-11-21 16:48:47'),
(8, 'Gold Lounge Exper', 'assets/images/gift-card-5.png', 1, NULL, 1, 5, 1, 1, NULL, '2024-11-21 15:37:52', '2024-11-21 16:48:51');

-- --------------------------------------------------------

--
-- Table structure for table `giftcard_design_pos`
--

CREATE TABLE `giftcard_design_pos` (
  `id` int(11) NOT NULL,
  `design_name` varchar(250) NOT NULL,
  `image` varchar(250) NOT NULL,
  `archive` tinyint(4) NOT NULL,
  `country_id` int(11) NOT NULL,
  `sortorder` int(11) NOT NULL,
  `giftcard_category_Id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `expiry_date` date NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `updated_by` int(11) NOT NULL,
  `brand_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `giftcard_design_pos`
--

INSERT INTO `giftcard_design_pos` (`id`, `design_name`, `image`, `archive`, `country_id`, `sortorder`, `giftcard_category_Id`, `status`, `expiry_date`, `created_date`, `updated_date`, `updated_by`, `brand_id`) VALUES
(9, 'Birthday', 'assets/images/gift-card-1.png', 1, 1, 1, 3, 1, '2025-01-31', '2024-11-21 11:12:27', '2024-11-21 17:19:40', 0, NULL),
(10, 'Birthday', 'assets/images/gift-card-2.png', 1, 1, 2, 3, 1, '2025-03-15', '2024-11-21 11:16:53', '2024-11-21 17:19:45', 0, NULL),
(11, 'Birthday', 'assets/images/gift-card-3.png', 1, 1, 3, 3, 1, '2025-03-13', '2024-11-21 11:17:54', '2024-11-21 17:19:51', 0, NULL),
(12, 'Christmas', 'assets/images/gift-card-5.png', 2, 1, 1, 3, 1, '2025-05-24', '2024-11-21 11:19:29', '2024-11-21 17:19:56', 0, NULL),
(13, 'Christmas', 'assets/images/gift-card-1.png', 2, 1, 2, 3, 1, '2025-02-19', '2024-11-21 11:20:34', '2024-11-21 17:19:59', 0, NULL),
(14, 'Christmas', 'assets/images/gift-card-5.png', 2, 1, 3, 3, 1, '2025-02-19', '2024-11-21 11:20:34', '2024-11-21 17:20:24', 0, NULL),
(15, 'Christmas', 'assets/images/gift-card-4.png', 2, 1, 4, 3, 1, '2025-02-19', '2024-11-21 11:20:34', '2024-11-21 17:20:19', 0, NULL),
(16, 'Kids', 'assets/images/gift-card-1.png', 3, 1, 1, 3, 1, '2025-03-29', '2024-11-21 11:22:39', '2024-11-21 17:20:02', 0, NULL),
(17, 'Kids', 'assets/images/gift-card-3.png', 3, 1, 2, 3, 1, '2025-03-29', '2024-11-21 11:22:39', '2024-11-21 17:20:14', 0, NULL),
(18, 'Kids', 'assets/images/gift-card-1.png', 3, 1, 3, 3, 1, '2025-03-29', '2024-11-21 11:22:39', '2024-11-21 17:20:05', 0, NULL),
(19, 'Kids', 'assets/images/gift-card-2.png', 3, 1, 4, 3, 1, '2025-03-29', '2024-11-21 11:22:39', '2024-11-21 17:20:10', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `giftcard_design_subcategory_pos`
--

CREATE TABLE `giftcard_design_subcategory_pos` (
  `giftcard_design_id` int(11) DEFAULT NULL,
  `subcategoty_id` int(11) DEFAULT NULL,
  `Is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `giftcard_physical_pos`
--

CREATE TABLE `giftcard_physical_pos` (
  `id` int(11) NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL,
  `price` float(11,2) DEFAULT NULL,
  `minimum_amount` float(11,2) DEFAULT NULL,
  `archive` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `giftcard_category_Id` int(11) NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `sortorder` int(11) DEFAULT NULL,
  `vista_Id` int(11) DEFAULT NULL,
  `bonus_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `giftcard_category_pos`
--
ALTER TABLE `giftcard_category_pos`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `giftcard_design_pos`
--
ALTER TABLE `giftcard_design_pos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `giftcard_physical_pos`
--
ALTER TABLE `giftcard_physical_pos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `giftcard_category_pos`
--
ALTER TABLE `giftcard_category_pos`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `giftcard_design_pos`
--
ALTER TABLE `giftcard_design_pos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `giftcard_physical_pos`
--
ALTER TABLE `giftcard_physical_pos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
