// Example: Mock data (replace with actual database logic)

  exports.getCategories = () => {
    return categories;
  };
  