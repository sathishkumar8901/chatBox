-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2024 at 02:09 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rds`
--

-- --------------------------------------------------------

--
-- Table structure for table `chatbox`
--

CREATE TABLE `chatbox` (
  `id` int(3) NOT NULL,
  `user_id` int(3) NOT NULL,
  `to_id` int(3) NOT NULL,
  `message` text NOT NULL,
  `read_status` int(3) NOT NULL DEFAULT 0 COMMENT '0-Unread,1-Read',
  `delete_status` int(3) NOT NULL DEFAULT 0 COMMENT '0-Not deleted,1-Deleted',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `chatbox`
--

INSERT INTO `chatbox` (`id`, `user_id`, `to_id`, `message`, `read_status`, `delete_status`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 'Hi this is from sathish', 1, 0, '2024-12-11 17:47:46', '2024-12-11 17:47:46'),
(2, 2, 1, 'Hi this is from saravana', 1, 0, '2024-12-11 17:49:16', '2024-12-11 17:49:16'),
(3, 1, 2, 'How are you? i\'m fine ', 0, 0, '2024-12-11 17:49:56', '2024-12-11 17:49:56'),
(4, 1, 2, 'This is just chat  box ', 1, 0, '2024-12-11 17:50:36', '2024-12-11 17:50:36');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(5) NOT NULL,
  `name` text NOT NULL,
  `password` text NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `password`, `status`) VALUES
(1, 'sathish', '$2a$10$ZpuAvTZJJNnMd1fS6A7dd.UErCWlmtk/xiZO.RcuVUtdAf1Z.7wHm', 1),
(2, 'saravana', '$2a$10$FjheGyz/RFiWx/xvwwP/ke8r8avOtysLsKTTqR1paLQQ2Imozc7J2', 1),
(8, 'velu', '$2a$10$Tq8Xo4uY6UbFmz5eK7/J5u5gHAdfpAVk1twEt72pciZqX.Gh22lBm', 1),
(9, 'kumar', '$2a$10$FvRbt4YsnQf4Z2kHTH0JHesL.A1uQr/jF/q7yz0R0HtC86k6bOv7y', 1),
(10, 'kumar', '$2a$10$vXT7Ozqy9ugtbgGwqjAcTuUt0evbu6ZxqP8gDaJEHamHqxXEyFH.y', 1),
(11, 'daniel', '$2a$10$dGzUtvRkyB6H1DeE2rT0a.5ceFMtyuQf1pZ3iBKS4XpB9UW31oqLW', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chatbox`
--
ALTER TABLE `chatbox`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chatbox`
--
ALTER TABLE `chatbox`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
